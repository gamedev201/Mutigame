
function startGame(game) {
    alert('Starting ' + game + '! Feature coming soon!');
}
